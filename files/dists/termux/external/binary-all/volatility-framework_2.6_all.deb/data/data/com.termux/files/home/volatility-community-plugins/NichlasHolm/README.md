Author: Nichlas Holm

See https://github.com/Memoryforensics for updates and licensing information.