Author: Kudelski Security

See https://github.com/kudelskisecurity for updates and license information. 