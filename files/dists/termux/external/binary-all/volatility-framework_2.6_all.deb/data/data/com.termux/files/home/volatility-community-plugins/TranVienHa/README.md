Author: Tran Vien Ha

See https://github.com/tranvienha/volatility-osint for updates and licensing information.