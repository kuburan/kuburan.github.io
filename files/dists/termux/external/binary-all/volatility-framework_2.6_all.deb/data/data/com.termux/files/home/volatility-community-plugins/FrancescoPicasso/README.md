Author: Francesco Picasso 

See https://github.com/dfirfpi/hotoloti for updates and license information. 