Author: Jeff Bryner

See https://github.com/jeffbryner for updates and license information. 