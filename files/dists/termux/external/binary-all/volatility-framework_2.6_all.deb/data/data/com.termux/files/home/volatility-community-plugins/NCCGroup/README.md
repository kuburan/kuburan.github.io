Author: NCC Group (Ollie Whitehouse)

See https://github.com/nccgroup for updates and license information. 