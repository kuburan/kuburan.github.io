Author: Csaba Barta

See https://github.com/csababarta for updates and license information. 