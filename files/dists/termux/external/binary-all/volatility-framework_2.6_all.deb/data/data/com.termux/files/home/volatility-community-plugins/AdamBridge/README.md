Author: Adam Bridge

See https://github.com/bridgeythegeek for updates and license information. 