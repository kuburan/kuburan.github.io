Author: Philip Huppert

See https://github.com/Phaeilo for updates and license information. 