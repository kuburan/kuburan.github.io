Author: Tyler Halfpop 

See https://github.com/tylerph3 for updates and licensing information. 