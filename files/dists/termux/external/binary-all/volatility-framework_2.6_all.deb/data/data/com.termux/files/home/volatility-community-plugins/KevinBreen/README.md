Author: Kevin Breen

See https://github.com/kevthehermit/volatility_plugins/tree/master/lastpass for updates and license information. 