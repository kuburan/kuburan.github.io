Author: Nick Gk

See https://github.com/ngkogkos for updates and license information. 