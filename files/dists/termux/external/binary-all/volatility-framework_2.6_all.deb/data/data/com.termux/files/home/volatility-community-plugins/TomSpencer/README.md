Author: Tom Spencer

See https://github.com/tomspencer for updates and license information. 