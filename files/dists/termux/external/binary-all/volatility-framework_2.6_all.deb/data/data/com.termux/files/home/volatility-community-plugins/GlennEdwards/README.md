Author: Glenn Edwards

See https://github.com/hiddenillusion for updates and license information. 