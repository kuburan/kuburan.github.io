Author: Stanislas Lejay

See https://github.com/P1kachu/VolatilityProfileScan for updates and license information.

