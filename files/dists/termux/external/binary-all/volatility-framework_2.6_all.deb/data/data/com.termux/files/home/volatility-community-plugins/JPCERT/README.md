Author: JPCERT/CC 

See https://github.com/JPCERTCC/aa-tools for updates and license information. 