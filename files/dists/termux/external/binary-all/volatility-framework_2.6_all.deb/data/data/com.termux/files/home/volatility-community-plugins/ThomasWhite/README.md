Author: Thomas White

See https://github.com/tribalchicken for updates and license information. 