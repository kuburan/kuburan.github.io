Author: Joe Greenwood

See https://github.com/4ARMED/volatility-attributeht for updates and license information.