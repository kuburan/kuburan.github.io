Author: Wyatt Roersma

See https://github.com/wroersma for updates and license information. 