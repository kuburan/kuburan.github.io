Author: Thomas Chopitea

See https://github.com/tomchop for updates and license information. 