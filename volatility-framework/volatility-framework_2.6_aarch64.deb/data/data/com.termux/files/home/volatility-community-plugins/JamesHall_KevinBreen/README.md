Author: James Hall and Kevin Breen

See https://github.com/kevthehermit/volatility_plugins/tree/master/usbstor for updates and license information. 