Author: Takahiro Haruyama

See https://github.com/TakahiroHaruyama for updates and license information. 