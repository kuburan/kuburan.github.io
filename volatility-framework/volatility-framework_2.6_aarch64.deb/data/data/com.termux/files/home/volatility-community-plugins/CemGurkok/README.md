Author: Cem Gurkok

See https://github.com/siliconblade for updates and license information. 