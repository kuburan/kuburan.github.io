Author: Fabien Periguad 

See https://bitbucket.org/cybertools/volatility_plugins/wiki/Home for updates and license information. 