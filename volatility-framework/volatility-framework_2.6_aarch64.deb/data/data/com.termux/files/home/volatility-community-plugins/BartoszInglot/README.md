Author: Bart Inglot 

See https://github.com/binglot for updates and license information.