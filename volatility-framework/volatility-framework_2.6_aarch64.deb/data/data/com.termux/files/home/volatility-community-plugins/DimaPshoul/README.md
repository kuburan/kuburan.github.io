Author: Dima Pshoul

See https://github.com/papadp for updates and license information. 