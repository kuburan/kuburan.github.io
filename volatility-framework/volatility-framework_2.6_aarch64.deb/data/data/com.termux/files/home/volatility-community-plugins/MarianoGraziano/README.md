Author: Mariano Graziano 

See https://github.com/emdel for updates and license information. 