Author: Dave Lasalle

See https://github.com/superponible for updates and license information. 